public class Main {
    public static void main(String[] args) {

    }
}
@RestController
@RequestMapping("/schedules")
public class ScheduleController {

    private final ScheduleService scheduleService;

    public ScheduleController(ScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    // 일정 조회(전체)
    @GetMapping
    public ResponseEntity<List<ScheduleResponseDto>> findAllSchedules() {
        return new ResponseEntity<>(scheduleService.findAllSchedules(), HttpStatus.OK);
    }

    // 일정 조회(단건)
    @GetMapping("/{id}")
    public ResponseEntity<ScheduleResponseDto> findScheduleById(@PathVariable Long id) {
        return new ResponseEntity<>(scheduleService.findScheduleById(id), HttpStatus.OK);
    }
    @Service
    public class ScheduleServiceImpl{

        private final ScheduleRepository scheduleRepository;

        public ScheduleServiceImpl(ScheduleRepository scheduleRepository) {
            this.scheduleRepository = scheduleRepository;
        }

        // 일정 조회(전체)
        public List<ScheduleResponseDto> findAllSchedules() {
            return scheduleRepository.findAllSchedules();
        }

        // 일정 조회(단건)
        public ScheduleResponseDto findScheduleById(Long id) {
            Schedule schedule = scheduleRepository.findScheduleByIdOrElseThrow(id);
            return new ScheduleResponseDto(schedule);
        }
        @Repository
        public class JdbcTemplateScheduleRepository {

            private final JdbcTemplate jdbcTemplate;

            public JdbcTemplateScheduleRepository(DataSource dataSource) {
                this.jdbcTemplate = new JdbcTemplate(dataSource);
            }


            // 일정조회(전체) 메서드
            public List<ScheduleResponseDto> findAllSchedules() {
                return jdbcTemplate.query("select * from schedule", scheduleRowMapper());
            }

            // 일정조회(단건) 메서드
            public Optional<Schedule> findScheduleById(Long id) {
                List<Schedule> result = jdbcTemplate.query("select * from schedule where id=?", scheduleRowMapperV2(), id);
                return result.stream().findAny();
            }

            // 일정수정 메서드
            @Override
            public int updateSchedule(Long id, String userName, String title, String contents) {
                return jdbcTemplate.update("update schedule set username = ?, title = ?, contents = ? where id = ?", userName, title, contents, id);
            }