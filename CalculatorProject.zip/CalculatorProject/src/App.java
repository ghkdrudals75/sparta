import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Calculator {
    private List<String> history;
    private double lastResult; // New field to store the last result

    public Calculator() {
        this.history = new ArrayList<>();
        this.lastResult = 0; // Initialize lastResult
    }

    public double calculate(double num1, double num2, char operator) {
        double result = 0;
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 == 0) {
                    System.out.println("0으로 나눌 수 없습니다.");
                    return Double.NaN;
                }
                result = num1 / num2;
                break;
            default:
                System.out.println("올바른 연산자를 입력하세요 (+, -, *, /).");
                return Double.NaN;
        }
        setLastResult(result); // Save the result to lastResult using setter
        addToHistory(num1, num2, operator, result); // Add the calculation to history
        return result;
    }

    public List<String> getHistory() {
        return history;
    }

    public double getLastResult() { // Getter for lastResult
        return lastResult;
    }

    // Setter for lastResult
    private void setLastResult(double result) {
        this.lastResult = result;
    }

    // Method to add an entry to history
    private void addToHistory(double num1, double num2, char operator, double result) {
        history.add(num1 + " " + operator + " " + num2 + " = " + result);
    }
}

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Calculator calculator = new Calculator();

        while (true) {
            System.out.print("첫 번째 숫자를 입력하세요 (exit 입력 시 종료): ");
            String input = sc.next();
            if (input.equalsIgnoreCase("exit")) {
                System.out.println("계산기를 종료합니다.");
                break;
            }

            double num1;
            try {
                num1 = Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.println("유효한 숫자를 입력하세요.");
                continue;
            }

            System.out.print("두 번째 숫자를 입력하세요: ");
            double num2 = sc.nextDouble();

            System.out.print("사칙연산 기호를 입력하세요 (+, -, *, /): ");
            char operator = sc.next().charAt(0);

            double result = calculator.calculate(num1, num2, operator);
            if (!Double.isNaN(result)) {
                System.out.println("결과: " + result);
            }
        }

        System.out.println("연산 기록:");
        for (String record : calculator.getHistory()) {
            System.out.println(record);
        }

        sc.close();
    }
}







