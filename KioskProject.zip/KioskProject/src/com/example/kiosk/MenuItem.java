package com.example.kiosk;

public class MenuItem {

 }

